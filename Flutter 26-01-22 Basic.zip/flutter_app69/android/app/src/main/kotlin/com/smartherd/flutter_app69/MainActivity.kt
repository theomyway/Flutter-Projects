package com.smartherd.flutter_app69

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
