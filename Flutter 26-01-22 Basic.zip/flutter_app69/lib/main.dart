import 'package:flutter/material.dart';
void main()
{
 runApp( MaterialApp( title: "My First Flutter App",

   home: new Material(
    color: Colors.cyan ,
    child:  Center( child: Text(
        "Hello World",
        textDirection: TextDirection.ltr
    )  ,
   ),)



   ,
 )
 );

}